import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import requests
import base64
from urllib.parse import parse_qsl, urlencode, quote
import os

try:
    import inputstreamhelper
    HAVE_INPUTSTREAM_HELPER = True
except ImportError:
    HAVE_INPUTSTREAM_HELPER = False

ADDON = xbmcaddon.Addon()
ADDON_ROOT = os.path.normpath(ADDON.getAddonInfo('path'))
DEFAULT_ICON = os.path.join(ADDON_ROOT, "resources", "media", "icon.png")
DEFAULT_FANART = os.path.join(ADDON_ROOT, "resources", "media", "fanart.jpg")

def get_channels():
    url = "https://soapbox.dishhome.com.np/soapboxdbcache/genre/liveDetails"
    headers = {
        "Accept": "application/json, text/plain, */*",
        "x-access-token": "undefined",
        "Authorization": "Bearer null",
        "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
        "Accept-Encoding": "gzip",
        "User-Agent": "okhttp/4.10.0"
    }
    data = {"account_id": "1"}
    response = requests.post(url, headers=headers, data=data)
    return response.json()

def build_url(query):
    return f"{sys.argv[0]}?{urlencode(query)}"

def build_genre_map(genre_details):
    """Build proper genre mapping from genre details"""
    genre_map = {}
    for genre in genre_details:
        for assoc in genre.get('genreassetassociation', []):
            genre_map[str(assoc['assetId'])] = {
                'name': genre['name'],
                'id': genre.get('id'),
                'sortOrder': assoc.get('sortOrder', 999)
            }
    return genre_map

def list_categories(handle):
    xbmcplugin.setContent(handle, 'videos')
    data = get_channels()
    genre_details = data['data'][0]['genreDetails']
    
    sorted_genres = sorted(genre_details, key=lambda x: x['name'])
    
    for genre in sorted_genres:
        list_item = xbmcgui.ListItem(label=genre['name'])
        icon = placeholder_url(genre['name'], size='300x300')
        list_item.setArt({'icon': icon, 'thumb': icon, 'fanart': DEFAULT_FANART})
        list_item.setInfo('video', {
            'title': genre['name'],
            'plot': f"Channels in {genre['name']} category"
        })
        url = build_url({'action': 'channels', 'category': genre['name']})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=list_item, isFolder=True)
    
    xbmcplugin.endOfDirectory(handle)

def get_stream_url(asset_url):
    """Transform stream URL properly"""
    if not asset_url:
        return ""
    
    if ".m3u8" in asset_url:
        base_url = asset_url.split("?")[0]
        stream_url = base_url.replace(".m3u8", ".mpd")
        return stream_url
    return asset_url

def placeholder_url(text, size='300x300'):
    text_with_newline = str(text).replace(' ', '\n')
    return f"https://placehold.co/{size}/white/red/png?text={quote(text_with_newline)}"

def list_channels(handle, category):
    xbmcplugin.setContent(handle, 'videos')
    
    PROTOCOL = 'mpd'
    DRM = 'com.widevine.alpha'
    
    if HAVE_INPUTSTREAM_HELPER:
        is_helper = inputstreamhelper.Helper(PROTOCOL, drm=DRM)
        if not is_helper.check_inputstream():
            xbmcgui.Dialog().ok('DRM Error', 'Widevine DRM is not setup. Please install/update Widevine CDM.')
            return
    else:
        xbmcgui.Dialog().ok('Missing Dependency', 'Please install script.module.inputstreamhelper from Kodi repository')
        return
        
    data = get_channels()
    asset_details = data['data'][1]['AssetDetails']['assetDetailsBasedOnId']
    genre_details = data['data'][0]['genreDetails']
    
    genre_map = build_genre_map(genre_details)
    
    sorted_assets = []
    for asset_id, asset in asset_details.items():
        if genre_map.get(str(asset_id), {}).get('name') == category:
            sorted_assets.append(asset)
    
    sorted_assets.sort(key=lambda x: x.get('logicalChannelNumber', 999))

    for asset in sorted_assets:
        title = f"{asset['title']}"
        stream_url = get_stream_url(asset['assetUrl'])
        if not stream_url:
            continue

        drm_headers = {
            'User-Agent': 'ReactNativeVideo/6.0.8024 (Linux;Android 14) ExoPlayerLib/2.11.4',
            'Content-Type': 'application/json',
            'Accept': '*/*',
        }

        drm_id_raw = asset.get('drmId', '') or ''
        drm_id = base64.b64encode(drm_id_raw.encode()).decode() if drm_id_raw else ''
        license_url = (f"https://cgdrm.dishhome.com.np:4443?PlayState=1&DrmSystem=Widevine"
                       f"&LoginName=ZGVtb3VzZXJAZGVtb2hvc3QuY29t&Password=ZGVtb3Bhc3N3b3Jk"
                       f"&KeyId={drm_id}&UniqueDeviceId=bnVsbA=="
                       f"&ContentUrl={base64.b64encode(stream_url.encode()).decode()}"
                       f"&DeviceTypeName=bnVsbA==")
        
        list_item = xbmcgui.ListItem(label=title)
        
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
        info_tag.setPlot(asset.get('description', ''))
        info_tag.setMediaType('video')
        
        if asset.get('currentEpg'):
            current_prog = asset['currentEpg'][0]
            epg_info = f"\n\nNow Playing: {current_prog.get('title', '')}"
            if current_prog.get('description'):
                epg_info += f"\n{current_prog['description']}"
            info_tag.setPlot(f"{asset.get('description', '')}{epg_info}")

        if asset.get('thumbnails') and asset['thumbnails'][0].get('thumbnailUrl'):
            icon_url = f"https://soapbox.dishhome.com.np/genesis/{asset['thumbnails'][0]['thumbnailUrl']}"
        else:
            icon_url = placeholder_url(asset.get('title', 'Channel'), size='300x300')

        list_item.setArt({
            'thumb': icon_url,
            'icon': icon_url,
            'fanart': DEFAULT_FANART
        })
        
        list_item.setProperty('IsPlayable', 'true')
        if asset.get('isDRMRequired'):
            list_item.setMimeType('application/dash+xml')
            list_item.setContentLookup(False)
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
            list_item.setProperty('inputstream.adaptive.license_type', DRM)
            list_item.setProperty('inputstream.adaptive.license_key', license_url)
            list_item.setProperty('inputstream.adaptive.stream_headers', urlencode(drm_headers))
        else:
            pass
        
        try:
            xbmcplugin.addDirectoryItem(handle=handle, url=stream_url, listitem=list_item, isFolder=False)
        except Exception as e:
            xbmc.log(f"[golive] addDirectoryItem error: {e}", xbmc.LOGERROR)

    xbmcplugin.endOfDirectory(handle)

def run(argv):
    handle = int(argv[1])
    params = dict(parse_qsl(argv[2][1:]))
    
    if params.get('action') == 'channels':
        list_channels(handle, params['category'])
    else:
        list_categories(handle)
